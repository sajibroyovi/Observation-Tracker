/**
 * observations.js - Observation Modal JavaScript Functions
 * 
 * This file contains all JavaScript functionality for the Observation Entry modal,
 * including team selection, image validation, and UI interactions.
 * 
 * Author: Shift Handover Application
 * Last Modified: 2026-02-08
 */

// ============================================================================
// TEAM SELECTION FUNCTIONALITY
// ============================================================================

/**
 * Initialize the team selection dropdown with checkbox-less selection
 * Handles team selection UI, badge rendering, and label updates
 */
function initializeTeamSelection() {
    const teamItems = document.querySelectorAll('.team-item');
    const selectAll = document.getElementById('selectAllTeams');
    const label = document.getElementById('teamDropdownLabel');
    const button = document.getElementById('teamDropdown');
    const container = document.getElementById('selectedTeamsContainer');
    const placeholder = document.getElementById('noTeamsPlaceholder');

    if (!teamItems.length) return; // Exit if no team items found

    /**
     * Updates the UI based on current team selection
     * - Renders selected team badges
     * - Updates dropdown label text
     * - Manages visual states
     */
    function updateTeamUI() {
        const checked = [];
        container.innerHTML = '';

        teamItems.forEach(item => {
            const checkbox = item.querySelector('.team-checkbox');
            const checkIcon = item.querySelector('.check-icon');

            if (checkbox.checked) {
                item.classList.add('bg-primary-soft', 'text-primary');
                checkIcon.classList.remove('opacity-0');
                checked.push(checkbox.value);

                // Create and append badge
                const badge = document.createElement('span');
                badge.className = 'badge bg-primary bg-opacity-10 text-primary border border-primary border-opacity-25 px-2 py-2 rounded-pill transition-all hover-scale shadow-sm';
                badge.style.fontSize = '0.75rem';

                const iconEl = document.createElement('i');
                iconEl.className = 'fa-solid fa-users me-1';

                const textEl = document.createTextNode(` ${checkbox.value}`);

                badge.appendChild(iconEl);
                badge.appendChild(textEl);
                container.appendChild(badge);
            } else {
                item.classList.remove('bg-primary-soft', 'text-primary');
                checkIcon.classList.add('opacity-0');
            }
        });

        // Update dropdown label and state
        if (checked.length === 0) {
            label.textContent = 'Select Impacted Teams';
            button.classList.remove('border-primary');
            if (placeholder) container.appendChild(placeholder);
        } else {
            if (checked.length === teamItems.length) {
                label.textContent = 'All Teams Selected';
            } else if (checked.length === 1) {
                label.textContent = checked[0];
            } else {
                label.textContent = checked.length + ' Teams Selected';
            }
            button.classList.add('border-primary');
        }
    }

    // Attach click handlers to team items
    teamItems.forEach(item => {
        item.addEventListener('click', function (e) {
            e.stopPropagation();
            const checkbox = this.querySelector('.team-checkbox');
            checkbox.checked = !checkbox.checked;
            updateTeamUI();
        });
    });

    // Attach handler to "Select All" button
    if (selectAll) {
        selectAll.addEventListener('click', function (e) {
            e.stopPropagation();
            const anyUnchecked = Array.from(teamItems).some(item => !item.querySelector('.team-checkbox').checked);
            teamItems.forEach(item => {
                item.querySelector('.team-checkbox').checked = anyUnchecked;
            });
            updateTeamUI();
        });
    }

    // Initialize UI on page load
    updateTeamUI();
}

// ============================================================================
// TECHNICIAN SELECTION FUNCTIONALITY
// ============================================================================

/**
 * Initialize the technician selection dropdown with search filtering
 * Handles single selection UI and search functionality
 */
function initializeTechnicianSelection() {
    // Handle both Add Modal and Update Page by using class-based lookups
    const dropdownContainers = document.querySelectorAll('.custom-technician-dropdown');
    
    dropdownContainers.forEach(container => {
        const searchInput = container.querySelector('.tech-search-field');
        const listContainer = container.querySelector('.tech-list-container');
        const techItems = container.querySelectorAll('.tech-item');
        const label = container.querySelector('.tech-dropdown-label');
        const hiddenInput = container.querySelector('.selected-tech-input');
        
        if (!techItems.length) return;

        // Search logic
        if (searchInput) {
            searchInput.addEventListener('input', function(e) {
                e.stopPropagation();
                const query = this.value.toLowerCase().trim();
                
                techItems.forEach(item => {
                    const text = item.textContent.toLowerCase();
                    if (text.includes(query)) {
                        item.style.setProperty('display', 'flex', 'important');
                    } else {
                        item.style.setProperty('display', 'none', 'important');
                    }
                });
            });
            // Stop search clicks from closing dropdown
            searchInput.addEventListener('click', e => e.stopPropagation());
        }

        // Selection logic
        techItems.forEach(item => {
            item.addEventListener('click', function(e) {
                e.preventDefault();
                e.stopPropagation();
                
                const value = this.getAttribute('data-value');
                const displayName = this.querySelector('span') ? this.querySelector('span').textContent : value;
                
                // Clear state ONLY for this dropdown container
                techItems.forEach(ti => {
                    ti.classList.remove('bg-primary-soft', 'text-primary');
                    const icon = ti.querySelector('.check-icon');
                    if (icon) icon.classList.add('opacity-0');
                });
                
                // Active selection
                this.classList.add('bg-primary-soft', 'text-primary');
                const icon = this.querySelector('.check-icon');
                if (icon) icon.classList.remove('opacity-0');
                
                // Set data
                if (label) label.textContent = displayName;
                if (hiddenInput) {
                    hiddenInput.value = value;
                    hiddenInput.dispatchEvent(new Event('change', { bubbles: true }));
                }

                // Close dropdown
                const toggle = container.querySelector('[data-bs-toggle="dropdown"]');
                if (toggle && typeof bootstrap !== 'undefined' && bootstrap.Dropdown) {
                    const bsDropdown = bootstrap.Dropdown.getInstance(toggle) || new bootstrap.Dropdown(toggle);
                    bsDropdown.hide();
                }
            });
        });
    });
}

// ============================================================================
// IMAGE UPLOAD VALIDATION
// ============================================================================

/**
 * Validates the number of images selected in file input
 * Enforces a maximum of 2 images and updates the visual counter
 * 
 * @param {HTMLInputElement} input - The file input element
 */
function validateImageCount(input) {
    const badge = document.getElementById('imageCountBadge');
    if (!badge) return; // Exit if badge element not found

    const count = input.files.length;

    if (count > 2) {
        alert("Please select maximum 2 images.");
        input.value = "";
        badge.textContent = "0 / 2 selected";
        badge.classList.remove('bg-primary', 'text-white', 'bg-info');
        badge.classList.add('bg-light', 'text-muted');
    } else {
        let totalSize = 0;
        for (let i = 0; i < count; i++) {
            totalSize += input.files[i].size;
            // Enforce 5MB size limit per file
            if (input.files[i].size > 5 * 1024 * 1024) {
                alert("File " + input.files[i].name + " exceeds the 5MB limit.");
                input.value = "";
                badge.textContent = "0 / 2 selected";
                badge.classList.remove('bg-info', 'text-white');
                badge.classList.add('bg-light', 'text-muted');
                return;
            }
        }

        const sizeInMB = (totalSize / (1024 * 1024)).toFixed(2);
        badge.textContent = count + " / 2 selected (" + sizeInMB + " MB)";

        if (count > 0) {
            badge.classList.remove('bg-light', 'text-muted');
            badge.classList.add('bg-info', 'text-white');
        } else {
            badge.classList.remove('bg-info', 'text-white');
            badge.classList.add('bg-light', 'text-muted');
        }
    }
}

// ============================================================================
// INITIALIZATION
// ============================================================================

/**
 * Initialize all observation modal functionality when DOM is ready
 */
document.addEventListener('DOMContentLoaded', function () {
    // Initialize team selection if elements exist
    if (document.querySelector('.team-item')) {
        initializeTeamSelection();
    }
    // Initialize technician selection if elements exist
    if (document.querySelector('.tech-item')) {
        initializeTechnicianSelection();
    }
});

// Export functions for global access
window.validateImageCount = validateImageCount;
window.initializeTeamSelection = initializeTeamSelection;
window.initializeTechnicianSelection = initializeTechnicianSelection;
