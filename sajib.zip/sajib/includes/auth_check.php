<?php
/**
 * Authentication Check - Include at the top of protected pages
 * 
 * This file initializes the session, checks authentication,
 * and loads the centralized function library.
 */

// Load centralized function library
require_once __DIR__ . '/functions.php';

// Initialize session and check authentication
requireAuth();

// Establish global database connection for backward compatibility
$conn = getConnection();

// Store user info for easy access (backward compatibility)
$user_id = $_SESSION['user_id'];
$user_name = $_SESSION['username'];
$user_role = $_SESSION['role'];

// All functions are now available from functions.php:
// - Database: getConnection(), closeConnection(), sanitizeInput(), executeQuery()
// - Auth: requireAuth(), getUserInfo(), isLoggedIn(), logout()
// - Permissions: hasPermission(), canViewModule(), isSuperAdmin(), isAdmin()
//               canEditL1(), canEditL2(), canAddObservation(), canEditGlobal(), canDispatchHandover()
// - Utility: getCurrentShift(), formatDate(), getTimestamp(), redirectTo()
//           showSuccess(), showError(), getSuccessMessage(), getErrorMessage()
//           validateFileUpload(), generateUniqueFilename()
?>
