<?php
/**
 * ============================================================================
 * SHIFT HANDOVER APPLICATION - FUNCTION LIBRARY
 * ============================================================================
 * 
 * Centralized library containing all reusable PHP functions for the
 * Shift Handover Application.
 * 
 * Sections:
 * 1. Database Functions
 * 2. Authentication & Session Functions
 * 3. Permission & Role Functions
 * 4. Utility Functions
 * 
 * @author Shift Handover Development Team
 * @version 1.0
 * @date 2026-02-08
 */

// ============================================================================
// 1. DATABASE FUNCTIONS
// ============================================================================

/**
 * Get database connection
 * 
 * @return mysqli Database connection object
 * @throws Exception if connection fails
 */
function getConnection() {
    $config = require_once __DIR__ . '/../config/database.php';
    
    $servername = "localhost";
    $username   = "root";
    $password   = "";
    $dbname     = "shift_hand_over";
    
    // Create connection
    $conn = mysqli_connect($servername, $username, $password, $dbname);
    
    // Check connection
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }
    
    return $conn;
}

/**
 * Close database connection
 * 
 * @param mysqli $conn Database connection to close
 * @return void
 */
function closeConnection($conn) {
    if ($conn) {
        mysqli_close($conn);
    }
}

/**
 * Sanitize user input to prevent SQL injection
 * 
 * @param mysqli $conn Database connection
 * @param string $data Data to sanitize
 * @return string Sanitized data
 */
function sanitizeInput($conn, $data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    $data = mysqli_real_escape_string($conn, $data);
    return $data;
}

/**
 * Execute a safe query with error handling
 * 
 * @param mysqli $conn Database connection
 * @param string $query SQL query to execute
 * @return mysqli_result|bool Query result or false on failure
 */
function executeQuery($conn, $query) {
    $result = mysqli_query($conn, $query);
    if (!$result) {
        error_log("Query Error: " . mysqli_error($conn));
        return false;
    }
    return $result;
}

// ============================================================================
// 2. AUTHENTICATION & SESSION FUNCTIONS
// ============================================================================

/**
 * Initialize session with timezone
 * 
 * @return void
 */
function initSession() {
    if (session_status() === PHP_SESSION_NONE) {
        date_default_timezone_set('Asia/Dhaka');
        session_start();
    }
}

/**
 * Check if user is authenticated, redirect to login if not
 * 
 * @param string $redirect_url URL to redirect to if not authenticated
 * @return void
 */
function requireAuth($redirect_url = 'login.php') {
    initSession();
    
    if (!isset($_SESSION['user_id'])) {
        header('Location: ' . $redirect_url);
        exit();
    }
}

/**
 * Get current user information
 * 
 * @return array User information (id, username, role)
 */
function getUserInfo() {
    return [
        'id' => $_SESSION['user_id'] ?? null,
        'username' => $_SESSION['username'] ?? null,
        'role' => $_SESSION['role'] ?? null
    ];
}

/**
 * Check if user is logged in
 * 
 * @return bool True if logged in, false otherwise
 */
function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

/**
 * Logout user and redirect
 * 
 * @param string $redirect_url URL to redirect after logout
 * @return void
 */
function logout($redirect_url = 'login.php') {
    initSession();
    session_destroy();
    header('Location: ' . $redirect_url);
    exit();
}

// ============================================================================
// 3. PERMISSION & ROLE FUNCTIONS
// ============================================================================

/**
 * Check if user has a specific permission/role
 * 
 * @param string $required_role Required role to check
 * @return bool True if user has permission, false otherwise
 */
function hasPermission($required_role) {
    if ($_SESSION['role'] === 'super_admin') {
        return true;
    }
    return $_SESSION['role'] === $required_role;
}

/**
 * Check if user can view a specific module
 * 
 * @param string $module_title Module title to check access for
 * @return bool True if user can view module, false otherwise
 */
function canViewModule($module_title) {
    if ($_SESSION['role'] === 'super_admin') {
        return true;
    }
    
    $allowed = $_SESSION['allowed_modules'] ?? [];
    if (!is_array($allowed)) {
        $allowed = explode(',', $allowed);
    }
    
    return in_array($module_title, $allowed);
}

/**
 * Check if user is a super admin
 * 
 * @return bool True if super admin, false otherwise
 */
function isSuperAdmin() {
    return $_SESSION['role'] === 'super_admin';
}

/**
 * Check if user is an admin
 * 
 * @return bool True if admin, false otherwise
 */
function isAdmin() {
    return $_SESSION['role'] === 'admin';
}

/**
 * Check if user can edit L1 observations
 * Super Admin and L1 users can edit L1
 * 
 * @return bool True if can edit L1, false otherwise
 */
function canEditL1() {
    return in_array($_SESSION['role'], ['super_admin', 'l1']);
}

/**
 * Check if user can edit L2 observations
 * Super Admin, Admin, and L2 users can edit L2
 * 
 * @return bool True if can edit L2, false otherwise
 */
function canEditL2() {
    return in_array($_SESSION['role'], ['super_admin', 'admin', 'l2']);
}

/**
 * Check if user can add observations
 * Super Admin and L1 users can add observations
 * 
 * @return bool True if can add observation, false otherwise
 */
function canAddObservation() {
    return in_array($_SESSION['role'], ['super_admin', 'l1']);
}

/**
 * Check if user can edit global modules
 * Everyone except L2 can edit global modules
 * L2 can only edit observations
 * 
 * @return bool True if can edit global, false otherwise
 */
function canEditGlobal() {
    return $_SESSION['role'] !== 'l2';
}

/**
 * Check if user can dispatch shift handover
 * Super Admin and Admin can dispatch handover
 * 
 * @return bool True if can dispatch, false otherwise
 */
function canDispatchHandover() {
    return in_array($_SESSION['role'], ['super_admin', 'admin']);
}

// ============================================================================
// 4. UTILITY FUNCTIONS
// ============================================================================

/**
 * Get current shift based on time
 * Morning: 6 AM to 2 PM (06:00 - 13:59)
 * Evening: 2 PM to 10 PM (14:00 - 21:59)
 * Night: 10 PM to 6 AM (22:00 - 05:59)
 * 
 * @return string Current shift (Morning, Evening, or Night)
 */
function getCurrentShift() {
    $hour = (int)date('H');
    
    // Morning: 6 AM to 2 PM (06:00 - 13:59)
    if ($hour >= 6 && $hour < 14) {
        return 'Morning';
    }
    
    // Evening: 2 PM to 10 PM (14:00 - 21:59)
    if ($hour >= 14 && $hour < 22) {
        return 'Evening';
    }
    
    // Night: 10 PM to 6 AM (22:00 - 05:59)
    return 'Night';
}

/**
 * Format date with specified format
 * 
 * @param string $date Date to format
 * @param string $format Format string (default: 'Y-m-d H:i:s')
 * @return string Formatted date
 */
function formatDate($date, $format = 'Y-m-d H:i:s') {
    if (empty($date)) {
        return '';
    }
    
    $timestamp = strtotime($date);
    if ($timestamp === false) {
        return $date; // Return original if parsing fails
    }
    
    return date($format, $timestamp);
}

/**
 * Get current timestamp in standard format
 * 
 * @return string Current timestamp
 */
function getTimestamp() {
    return date('Y-m-d H:i:s');
}

/**
 * Redirect to a URL
 * 
 * @param string $url URL to redirect to
 * @return void
 */
function redirectTo($url) {
    header('Location: ' . $url);
    exit();
}

/**
 * Display success message
 * 
 * @param string $message Success message to display
 * @return void
 */
function showSuccess($message) {
    $_SESSION['success_message'] = $message;
}

/**
 * Display error message
 * 
 * @param string $message Error message to display
 * @return void
 */
function showError($message) {
    $_SESSION['error_message'] = $message;
}

/**
 * Get and clear success message
 * 
 * @return string|null Success message or null
 */
function getSuccessMessage() {
    if (isset($_SESSION['success_message'])) {
        $message = $_SESSION['success_message'];
        unset($_SESSION['success_message']);
        return $message;
    }
    return null;
}

/**
 * Get and clear error message
 * 
 * @return string|null Error message or null
 */
function getErrorMessage() {
    if (isset($_SESSION['error_message'])) {
        $message = $_SESSION['error_message'];
        unset($_SESSION['error_message']);
        return $message;
    }
    return null;
}

/**
 * Validate file upload
 * 
 * @param array $file File from $_FILES
 * @param array $allowed_types Allowed MIME types
 * @param int $max_size Maximum file size in bytes
 * @return array ['success' => bool, 'message' => string]
 */
function validateFileUpload($file, $allowed_types = [], $max_size = 5242880) {
    // Check if file was uploaded
    if (!isset($file['tmp_name']) || empty($file['tmp_name'])) {
        return ['success' => false, 'message' => 'No file uploaded'];
    }
    
    // Check for upload errors
    if ($file['error'] !== UPLOAD_ERR_OK) {
        return ['success' => false, 'message' => 'File upload error: ' . $file['error']];
    }
    
    // Check file size
    if ($file['size'] > $max_size) {
        $max_mb = $max_size / 1048576;
        return ['success' => false, 'message' => "File size exceeds {$max_mb}MB limit"];
    }
    
    // Check file type if specified
    if (!empty($allowed_types)) {
        $file_type = mime_content_type($file['tmp_name']);
        if (!in_array($file_type, $allowed_types)) {
            return ['success' => false, 'message' => 'Invalid file type'];
        }
    }
    
    return ['success' => true, 'message' => 'File validation passed'];
}

/**
 * Generate a unique filename
 * 
 * @param string $original_name Original filename
 * @return string Unique filename
 */
function generateUniqueFilename($original_name) {
    $extension = pathinfo($original_name, PATHINFO_EXTENSION);
    $filename = pathinfo($original_name, PATHINFO_FILENAME);
    $unique = uniqid() . '_' . time();
    return $filename . '_' . $unique . '.' . $extension;
}
