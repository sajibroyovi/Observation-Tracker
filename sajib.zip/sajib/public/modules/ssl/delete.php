<?php
require_once __DIR__ . '/../../../config/app.php'; include_once INCLUDES_PATH . '/auth_check.php';


if (!isSuperAdmin()) {
    header("Location: ../viewdata/view_ssl.php?error=unauthorized");
    exit;
}

if (isset($_GET['id'])) {
    $id = mysqli_real_escape_string($conn, $_GET['id']);

    $sql = "DELETE FROM ssl_certificate WHERE serial_no = '$id'";

    if (mysqli_query($conn, $sql)) {
        header("Location: ../viewdata/view_ssl.php?msg=deleted");
    } else {
        header("Location: ../viewdata/view_ssl.php?msg=error&details=" . urlencode(mysqli_error($conn)));
    }
} else {
    header("Location: ../viewdata/view_ssl.php?msg=noid");
}

mysqli_close($conn);
exit;
?>



