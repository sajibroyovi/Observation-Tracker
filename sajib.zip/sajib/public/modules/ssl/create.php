<?php
require_once __DIR__ . '/../../../config/app.php'; include_once INCLUDES_PATH . '/auth_check.php';


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $certificate_name = mysqli_real_escape_string($conn, $_POST['certificate_name']);
    $expiration_date = mysqli_real_escape_string($conn, $_POST['expiration_date']);
    $renewal_status = mysqli_real_escape_string($conn, $_POST['renewal_status']);
    $issues = mysqli_real_escape_string($conn, $_POST['issues']);

    
    $created_by = $_SESSION['username'];

    // Insert into ssl_certificate table
    $sql = "INSERT INTO ssl_certificate (certificate_name, expiration_date, renewal_status, issues, created_by) 
            VALUES ('$certificate_name', '$expiration_date', '$renewal_status', '$issues', '$created_by')";

    if (mysqli_query($conn, $sql)) {
        header('Location: ' . BASE_URL . '/index.php?status=success&msg=' . urlencode('SSL Certificate record inserted successfully'));
    } else {
        header('Location: ' . BASE_URL . '/index.php?status=error&msg=' . urlencode("Error: " . mysqli_error($conn)));
    }

    mysqli_close($conn);
}
?>




