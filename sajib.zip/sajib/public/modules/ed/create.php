<?php
require_once __DIR__ . '/../../../config/app.php'; include_once INCLUDES_PATH . '/auth_check.php'; 
 if ($_SERVER["REQUEST_METHOD"] == "POST") 
    {
         // Assuming form data from one of the modals, e.g., for service enable/disable 
         $service_name = mysqli_real_escape_string($conn, $_POST['service_name']); 
         $action_date = mysqli_real_escape_string($conn, $_POST['action_date']);
          $action_taken = mysqli_real_escape_string($conn, $_POST['action_taken']);
            $action_taken_by = mysqli_real_escape_string($conn, $_POST['action_taken_by']); 
           $reference = mysqli_real_escape_string($conn, $_POST['reference']);
           
           $created_by = $_SESSION['username'];
            // Assuming table name 'service_enable_disable' - adjust as needed
             $sql = "INSERT INTO enable_disable (service_name, action_date, action_taken, action_taken_by, reference, created_by) VALUES ('$service_name', '$action_date', '$action_taken', '$action_taken_by', '$reference', '$created_by')"; 
             if (mysqli_query($conn, $sql)) { 
                header('Location: ' . BASE_URL . '/index.php?status=success&msg=' . urlencode('Service Enable/Disable record inserted successfully'));
             } 
             else
                 {
                    header('Location: ' . BASE_URL . '/index.php?status=error&msg=' . urlencode("Error: " . mysqli_error($conn)));
                 }
    }
    mysqli_close($conn);
?>




