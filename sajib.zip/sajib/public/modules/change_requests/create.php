<?php
require_once __DIR__ . '/../../../config/app.php'; include_once INCLUDES_PATH . '/auth_check.php';


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Assuming form data from the CR List modal
    $cr_subject = mysqli_real_escape_string($conn, $_POST['cr_subject']);
    $impacted_area = mysqli_real_escape_string($conn, $_POST['impacted_area']);
    $cr_start_time = mysqli_real_escape_string($conn, $_POST['cr_start_time']);
    $cr_end_time = mysqli_real_escape_string($conn, $_POST['cr_end_time']);
    $downtime = mysqli_real_escape_string($conn, $_POST['downtime']);
    $cr_meeting_attended = mysqli_real_escape_string($conn, $_POST['cr_meeting_attended']);

    
    $created_by = $_SESSION['username'];

    // Assuming table name 'cr_list' - adjust as needed
    $sql = "INSERT INTO cr_list (cr_subject, impacted_area, cr_start_time, cr_end_time, downtime, cr_meeting_attended, created_by) 
            VALUES ('$cr_subject', '$impacted_area', '$cr_start_time', '$cr_end_time', '$downtime', '$cr_meeting_attended', '$created_by')";

    if (mysqli_query($conn, $sql)) {
        header('Location: ' . BASE_URL . '/index.php?status=success&msg=' . urlencode('Change Request record inserted successfully'));
    } else {
        header('Location: ' . BASE_URL . '/index.php?status=error&msg=' . urlencode("Error: " . mysqli_error($conn)));
    }

    mysqli_close($conn);
}
?>




