<?php
require_once __DIR__ . '/../../../config/app.php'; include_once INCLUDES_PATH . '/auth_check.php';


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $subject_lines = $_POST['subject_lines'];
    $priority = mysqli_real_escape_string($conn, $_POST['priority']);
    $status = mysqli_real_escape_string($conn, $_POST['status']);

    // Split subject lines by newline
    $lines = explode("\n", $subject_lines);
    
    
    $created_by = $_SESSION['username'];

    $inserted_count = 0;
    foreach($lines as $line) {
        $line = trim($line);
        if(!empty($line)) {
            $line_escaped = mysqli_real_escape_string($conn, $line);
            
            // Insert into pending_mail table
            $sql = "INSERT INTO pending_mail (subject_line, priority, status, created_by) 
                    VALUES ('$line_escaped', '$priority', '$status', '$created_by')";
              if (mysqli_query($conn, $sql)) {
                $inserted_count++;
            }
        }
    }

    if ($inserted_count > 0) {
        header('Location: ' . BASE_URL . '/index.php?status=success&msg=' . urlencode('Pending Mail record inserted successfully'));
    } else {
        header('Location: ' . BASE_URL . '/index.php?status=error&msg=' . urlencode('Pending Mail record inserted successfully'));
    }

    mysqli_close($conn);
}
?>




