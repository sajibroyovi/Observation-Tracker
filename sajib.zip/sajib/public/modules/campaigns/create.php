<?php
require_once __DIR__ . '/../../../config/app.php'; include_once INCLUDES_PATH . '/auth_check.php';


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $campaign_names = $_POST['campaign_names'];
    $start_date = mysqli_real_escape_string($conn, $_POST['start_date']);
   
    $status = mysqli_real_escape_string($conn, $_POST['status']);
    $description = mysqli_real_escape_string($conn, $_POST['description']);

    // Split campaign names by newline
    $names = explode("\n", $campaign_names);
    
    
    $created_by = $_SESSION['username'];

    $inserted_count = 0;
    foreach($names as $name) {
        $name = trim($name);
        if(!empty($name)) {
            $name_escaped = mysqli_real_escape_string($conn, $name);
            
            // Insert into campaign table
            $sql = "INSERT INTO campaign (campaign_name, start_date, status, description, created_by) 
                    VALUES ('$name_escaped', '$start_date', '$status', '$description', '$created_by')";

            if (mysqli_query($conn, $sql)) {
                $inserted_count++;
            }
        }
    }

    if ($inserted_count > 0) {
        header('Location: ' . BASE_URL . '/index.php?status=success&msg=' . urlencode("$inserted_count Campaign record(s) inserted successfully"));
    } else {
        header('Location: ' . BASE_URL . '/index.php?status=error&msg=' . urlencode('Campaign record inserted successfully'));
    }

    mysqli_close($conn);
}
?>




