<?php
require_once __DIR__ . '/../../../config/app.php'; include_once INCLUDES_PATH . '/auth_check.php';


if (!isSuperAdmin()) {
    header("Location: ../viewdata/view_campaign.php?error=unauthorized");
    exit;
}

if (isset($_GET['id'])) {
    $id = mysqli_real_escape_string($conn, $_GET['id']);

    $sql = "DELETE FROM campaign WHERE serial_no = '$id'";

    if (mysqli_query($conn, $sql)) {
        header("Location: ../viewdata/view_campaign.php?msg=deleted");
    } else {
        header("Location: ../viewdata/view_campaign.php?msg=error&details=" . urlencode(mysqli_error($conn)));
    }
} else {
    header("Location: ../viewdata/view_campaign.php?msg=noid");
}

mysqli_close($conn);
exit;
?>



