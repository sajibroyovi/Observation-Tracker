<?php
require_once __DIR__ . '/../../../config/app.php'; include_once INCLUDES_PATH . '/auth_check.php';


if (!isSuperAdmin()) {
    header("Location: ../viewdata/view_observations.php?error=unauthorized");
    exit;
}

if (isset($_GET['id'])) {
    $id = mysqli_real_escape_string($conn, $_GET['id']);

    $sql = "DELETE FROM observations WHERE serial_no = '$id'";

    if (mysqli_query($conn, $sql)) {
        header("Location: view.php?msg=deleted");
    } else {
        header("Location: view.php?msg=error&details=" . urlencode(mysqli_error($conn)));
    }
} else {
    header("Location: view.php?msg=noid");
}

mysqli_close($conn);

