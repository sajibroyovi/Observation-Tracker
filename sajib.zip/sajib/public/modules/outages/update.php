<?php
require_once __DIR__ . '/../../../config/app.php'; include_once INCLUDES_PATH . '/auth_check.php';


if (isset($_GET['id'])) {
    $id = mysqli_real_escape_string($conn, $_GET['id']);

    // Fetch existing record
    $sql = "SELECT * FROM service_outage WHERE serial_no = '$id'";
    $result = mysqli_query($conn, $sql);

    if (mysqli_num_rows($result) == 1) {
        $row = mysqli_fetch_assoc($result);
    } else {
        echo "Record not found";
        exit;
    }
} else {
    echo "No ID provided";
    exit;
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = mysqli_real_escape_string($conn, $_POST['id']);
    $details = mysqli_real_escape_string($conn, $_POST['details']);
    $incident_id = mysqli_real_escape_string($conn, $_POST['incident_id']);
    $problem_ticket = mysqli_real_escape_string($conn, $_POST['problem_ticket']);
    $technician = mysqli_real_escape_string($conn, $_POST['technician']);
    $status = mysqli_real_escape_string($conn, $_POST['status']);

    $sql = "UPDATE service_outage SET 
            details = '$details', 
            incident_id = '$incident_id', 
            problem_ticket = '$problem_ticket', 
            technician = '$technician', 
            status = '$status',
            edited_by = '{$_SESSION['username']}',
            edited_at = NOW() 
            WHERE serial_no = '$id'";

    if (mysqli_query($conn, $sql)) {
        echo "<script>alert('Record updated successfully'); window.location.href='/Shift%20Hand%20Over/sajib/viewdata/view_outage.php';</script>";
    } else {
        echo "Error updating record: " . mysqli_error($conn);
    }

    mysqli_close($conn);
    exit;
}

mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Service Outage | Shift Handover</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/7.0.1/css/all.min.css">
    <link rel="stylesheet" href="<?= ASSETS_URL ?>/css/style.css">
    <script src="<?= ASSETS_URL ?>/js/script.js" defer></script>
</head>

<body>
    <div class="dashboard-container">
        <?php include INCLUDES_PATH . '/sidebar.php'; ?>
        <div class="main-content">
            <div class="container-fluid ps-0 mt-3">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <div>
                        <h1 class="view-header fw-bold mb-1"><i class="fa-solid fa-triangle-exclamation text-danger me-2"></i> Update Service Outage</h1>
                        <p class="text-muted small mb-0">Modify incident details, technical assignments, and resolution progress.</p>
                    </div>
                    <a href="../viewdata/view_outage.php" class="btn btn-primary btn-sm rounded-pill px-4 shadow-sm fw-bold">
                        <i class="fa-solid fa-arrow-left me-1"></i> Back to List
                    </a>
                </div>

                <div class="row justify-content-center">
                    <div class="col-md-9 col-lg-8">
                        <div class="glass-card p-5 shadow-lg border-0">
                            <form method="POST" action="">
                                <input type="hidden" name="id" value="<?php echo $row['serial_no']; ?>">

                                <div class="mb-4">
                                    <label for="details" class="form-label small fw-bold text-muted text-uppercase">Incident Details</label>
                                    <textarea class="form-control bg-light border-0 shadow-sm p-3" name="details" id="details" rows="4" required placeholder="Provide a detailed description of the outage..."><?php echo htmlspecialchars($row['details']); ?></textarea>
                                </div>

                                <div class="row g-4 mb-4">
                                    <div class="col-md-6">
                                        <label for="incident_id" class="form-label small fw-bold text-muted text-uppercase">Incident ID</label>
                                        <input type="text" class="form-control bg-light border-0 shadow-sm p-3" name="incident_id" id="incident_id"
                                            value="<?php echo htmlspecialchars($row['incident_id']); ?>" required placeholder="INC0000123">
                                    </div>

                                    <div class="col-md-6">
                                        <label for="problem_ticket" class="form-label small fw-bold text-muted text-uppercase">Problem Ticket</label>
                                        <input type="text" class="form-control bg-light border-0 shadow-sm p-3" name="problem_ticket" id="problem_ticket"
                                            value="<?php echo htmlspecialchars($row['problem_ticket']); ?>" placeholder="PRB0000456">
                                    </div>

                                    <div class="col-md-6">
                                        <label for="technician" class="form-label small fw-bold text-muted text-uppercase">Assigned Technician</label>
                                        <input type="text" class="form-control bg-light border-0 shadow-sm p-3" name="technician" id="technician"
                                            value="<?php echo htmlspecialchars($row['technician']); ?>" required placeholder="Name of technician">
                                    </div>

                                    <div class="col-md-6">
                                        <label for="status" class="form-label small fw-bold text-muted text-uppercase">Resolution Status</label>
                                        <select class="form-select bg-light border-0 shadow-sm p-3" name="status" id="status" required>
                                            <option value="resolved" <?php if ($row['status'] == 'resolved') echo 'selected'; ?>>Resolved</option>
                                            <option value="in_progress" <?php if ($row['status'] == 'in_progress') echo 'selected'; ?>>In Progress</option>
                                            <option value="pending" <?php if ($row['status'] == 'pending') echo 'selected'; ?>>Pending</option>
                                        </select>
                                    </div>
                                </div>

                                <div class="alert alert-danger border-0 rounded-3 small mb-4 bg-danger bg-opacity-10 text-danger">
                                    <i class="fa-solid fa-user-pen me-2"></i> Last update by <b><?php echo htmlspecialchars($row['edited_by'] ?? 'Initial Reporter'); ?></b> on <?php echo date('d M, Y H:i', strtotime($row['edited_at'] ?? $row['created_at'])); ?>
                                </div>

                                <div class="d-grid mt-5">
                                    <button type="submit" class="btn btn-danger py-3 fw-bold rounded-pill shadow-lg">
                                        <i class="fa-solid fa-check-circle me-2"></i> Confirm Incident Update
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div> <!-- End container-fluid -->
        </div> <!-- End main-content -->
    </div> <!-- End dashboard-container -->

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>



