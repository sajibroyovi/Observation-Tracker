<?php
require_once __DIR__ . '/../../../config/app.php'; include_once INCLUDES_PATH . '/auth_check.php';


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Assuming form data from the Service Outage modal
    $details = mysqli_real_escape_string($conn, $_POST['details']);
    $incident_id = mysqli_real_escape_string($conn, $_POST['incident_id']);
    $problem_ticket = mysqli_real_escape_string($conn, $_POST['problem_ticket']);
    $status = mysqli_real_escape_string($conn, $_POST['status']);
    $technician = mysqli_real_escape_string($conn, $_POST['technician']);

    
    $created_by = $_SESSION['username'];

    // Assuming table name 'service_outage' - adjust as needed
    $sql = "INSERT INTO service_outage (details, incident_id, problem_ticket, status, technician, created_by) 
            VALUES ('$details', '$incident_id', '$problem_ticket', '$status', '$technician', '$created_by')";

    if (mysqli_query($conn, $sql)) {
        header('Location: ' . BASE_URL . '/index.php?status=success&msg=' . urlencode('Service Outage record inserted successfully'));
    } else {
        header('Location: ' . BASE_URL . '/index.php?status=error&msg=' . urlencode("Error: " . mysqli_error($conn)));
    }

    mysqli_close($conn);
}
?>






