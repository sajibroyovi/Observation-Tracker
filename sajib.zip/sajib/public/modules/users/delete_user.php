<?php
require_once __DIR__ . '/../../../config/app.php'; 
include_once INCLUDES_PATH . '/auth_check.php';

if (!isSuperAdmin()) {
    header('Location: ' . BASE_URL . '/index.php');
    exit();
}

if (isset($_GET['id'])) {
    $id = mysqli_real_escape_string($conn, $_GET['id']);

    // Prevent self-deletion
    $check_sql = "SELECT username FROM users WHERE id = '$id'";
    $check_res = mysqli_query($conn, $check_sql);
    $user_to_delete = mysqli_fetch_assoc($check_res);

    if ($user_to_delete && $user_to_delete['username'] === $_SESSION['username']) {
        echo "<script>alert('You cannot delete your own account.'); window.location.href='manage.php';</script>";
        exit();
    }

    $sql = "DELETE FROM users WHERE id = '$id'";

    if (mysqli_query($conn, $sql)) {
        echo "<script>alert('User deleted successfully'); window.location.href='manage.php';</script>";
        exit();
    } else {
        echo "Error deleting record: " . mysqli_error($conn);
    }
} else {
    header("Location: manage.php");
    exit();
}
?>
