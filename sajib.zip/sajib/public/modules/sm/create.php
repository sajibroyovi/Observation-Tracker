<?php
require_once __DIR__ . '/../../../config/app.php'; include_once INCLUDES_PATH . '/auth_check.php';  
if ($_SERVER["REQUEST_METHOD"] == "POST") 
    {
         // Assuming form data from the Pending Mail modal
          $subject_line = mysqli_real_escape_string($conn, $_POST['subject_line']);
          $priority = mysqli_real_escape_string($conn, $_POST['priority']);
          $status = mysqli_real_escape_string($conn, $_POST['status']);         
          
          
          $created_by = $_SESSION['username'];

          // Assuming table name 'security_mail' - adjust as needed
           $sql = "INSERT INTO security_mail (subject_line, priority, status, created_by) VALUES ('$subject_line', '$priority', '$status', '$created_by')"; 
           if (mysqli_query($conn, $sql)) { 
            header('Location: ' . BASE_URL . '/index.php?status=success&msg=' . urlencode('Security Record inserted successfully'));
        } 
        else 
            { 
                header('Location: ' . BASE_URL . '/index.php?status=error&msg=' . urlencode("Error: " . mysqli_error($conn)));
            }
         mysqli_close($conn); 
    }
  ?>




