<?php
require_once __DIR__ . '/../../../config/app.php'; include_once INCLUDES_PATH . '/auth_check.php';  
if ($_SERVER["REQUEST_METHOD"] == "POST") 
    {
         // Assuming form data from the Pending Mail modal
          $subject_line = mysqli_real_escape_string($conn, $_POST['subject_line']); 
          $status = mysqli_real_escape_string($conn, $_POST['status']);
          $start_date = mysqli_real_escape_string($conn, $_POST['start_date']);
          
          
          $created_by = $_SESSION['username'];
   
           $sql = "INSERT INTO promo_banner (subject_line, status, start_time, created_by) VALUES ('$subject_line', '$status', '$start_date', '$created_by')"; 
           if (mysqli_query($conn, $sql)) { 
                header('Location: ' . BASE_URL . '/index.php?status=success&msg=' . urlencode('Promo Banner record inserted successfully'));
            } 
            else 
            { 
                header('Location: ' . BASE_URL . '/index.php?status=error&msg=' . urlencode("Error: " . mysqli_error($conn)));
            }
         mysqli_close($conn); 
    }
   ?>




