<?php
require_once __DIR__ . '/../../../config/app.php'; include_once INCLUDES_PATH . '/auth_check.php';


// Only Super Admins can delete records
if (!isSuperAdmin()) {
    header("Location: ../viewdata/view_banner.php?error=unauthorized");
    exit;
}

if (isset($_GET['id'])) {
    $id = mysqli_real_escape_string($conn, $_GET['id']);

    $sql = "DELETE FROM promo_banner WHERE serial_no = '$id'";

    if (mysqli_query($conn, $sql)) {
        header("Location: ../viewdata/view_banner.php?msg=deleted");
    } else {
        header("Location: ../viewdata/view_banner.php?msg=error&details=" . urlencode(mysqli_error($conn)));
    }
} else {
    header("Location: ../viewdata/view_banner.php?msg=noid");
}

mysqli_close($conn);
exit;
?>



